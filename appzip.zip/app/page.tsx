'use client'
import { RootState } from '@/store/store';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useSelector } from 'react-redux';

const page = () => {

  return (
    <div>page</div>
  )
}

export default page;